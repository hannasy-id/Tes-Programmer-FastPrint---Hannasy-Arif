<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MPengaturanProduk extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
	
	public function getAllKategori(){
		$queryKategori="SELECT * FROM kategori";		
		return $this->db->query($queryKategori)->result_array();
	}
	
	public function getAllStatus(){
		$queryStatus = "SELECT * FROM status";
		return $this->db->query($queryStatus)->result_array();
	}
	
	public function getProduk($id_produk){
		$baseQuery = "SELECT 
						produk.id_produk AS id_produk,
						produk.nama_produk AS nama_produk,
						produk.harga AS harga,
						produk.kategori_id AS id_kategori,
						kategori.nama_kategori AS nama_kategori,
						produk.status_id AS id_status,
						status.nama_status AS status
						FROM produk
						INNER JOIN kategori ON produk.kategori_id=kategori.id_kategori
						INNER JOIN status ON produk.status_id=status.id_status
						WHERE produk.id_produk=$id_produk
					";
		
		return $this->db->query($baseQuery)->row_array();
	}
	
	public function insertProduk($idProduk, $namaProduk, $harga, $kategori, $status){
		$data=[
			'id_produk' => $idProduk,
			'nama_produk' => $namaProduk,
			'harga' => $harga,
			'kategori_id' => $kategori,
			'status_id' => $status
		
		];
		
		$queryInsert = "INSERT INTO produk (id_produk, nama_produk, harga, kategori_id, status_id)
						VALUES (?, ?, ?, ?, ?);
					";
					
		return $this->db->query($queryInsert, $data);
	}
	
	public function updateProduk($idProduk, $namaProduk, $harga, $kategori, $status){
		
		$data=[
			'id_produk' => $idProduk,
			'nama_produk' => $namaProduk,
			'harga' => $harga,
			'kategori_id' => $kategori,
			'status_id' => $status
		
		];
		
		$queryInsert = "UPDATE produk SET 
							id_produk = ?, 
							nama_produk = ?,
							harga = ?,
							kategori_id = ?,
							status_id = ?
						WHERE id_produk = ?;
					";
					
		return $this->db->query($queryInsert, [$data['id_produk'], $data['nama_produk'], $data['harga'], $data['kategori_id'], $data['status_id'], $data['id_produk']]);
	
	}
	
	public function deleteAllTable(){
		$queryDelete = "DELETE FROM produk";
		$this->db->query($queryDelete);
		
		$queryDelete = "DELETE FROM kategori";
		$this->db->query($queryDelete);
		
		$queryDelete = "DELETE FROM status";
		$this->db->query($queryDelete);
		
	}
	
	public function deleteProduk($idProduk){
		$query = "DELETE FROM produk WHERE id_produk = $idProduk";
		$this->db->query($query);
	}

}

