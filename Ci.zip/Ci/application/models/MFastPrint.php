<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MFastPrint extends CI_Model {

    public function __construct() {
        parent::__construct();
        
    }
	
	public function getAllProduk(){
		$strQuery="
					SELECT 
					produk.id_produk AS id_produk,
					produk.nama_produk,
					produk.harga,
					kategori.nama_kategori,
					status.nama_status
					FROM produk
					INNER JOIN kategori ON produk.kategori_id=kategori.id_kategori
					INNER JOIN status ON produk.status_id=status.id_status
					WHERE status.nama_status='bisa dijual'
				";
		$dataProduk = $this->db->query($strQuery);
		//print_r($dataProduk->result_array());
		return $dataProduk->result_array();
	}

}
