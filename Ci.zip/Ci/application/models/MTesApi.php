<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MTesApi extends CI_Model {

    // Konstruktor untuk memuat database
    public function __construct() {
        parent::__construct();
    }
	
	public function getDataProduk() {
		
		$url = "https://recruitment.fastprint.co.id/tes/api_tes_programmer"; 
		
		date_default_timezone_set("Asia/Jakarta");
		$jam = (int)date('H'); 
		if ((int)date('i') > 0) {
			$jam = str_pad(((int)date('H') + 1), 2, "0", STR_PAD_LEFT);
		}
		
		$tgl = str_pad((int)date('d'), 2, "0", STR_PAD_LEFT);
		$bulan = str_pad((int)date('m'), 2, "0", STR_PAD_LEFT);
		$tahun = (int)date('y');
		
		$username = "tesprogrammer".$tgl.$bulan.$tahun."C".$jam;
		$password = md5("bisacoding-".$tgl."-".$bulan."-".$tahun);
		
		
		$postData = [
			"username" => $username,
			"password" => $password
		];

		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData)); // Konversi array ke x-www-form-urlencoded
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		//
		
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);

		$response = curl_exec($ch);
		
		if (curl_errno($ch)) {
			echo 'Error:' . curl_error($ch);
		}

		curl_close($ch);
		
		//echo json_encode($response);
		return json_decode($response, true)['data'];
	}
	
}