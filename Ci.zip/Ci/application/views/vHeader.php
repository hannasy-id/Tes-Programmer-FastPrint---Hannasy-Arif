<!doctype html>
<html lang="en">
  <head>
	<link rel="shortcut icon" href="<?=site_url('assets/images/favicon.png')?>" type=image/png />
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>FastPrint</title>
    <!-- Bootstrap CSS -->
	<link href="<?=site_url('assets/css/bootstrap.min.css')?>" rel="stylesheet">
	<!-- DataTables CSS -->
	<link href="<?=site_url('assets/css/dataTables.bootstrap5.min.css')?>" rel="stylesheet">
  
  </head>
  <body>
    <!--h1>Hello, world!</h1-->
	<nav class="navbar navbar-expand-lg bg-body-tertiary mb-4">
	  <div class="container-fluid">
		<a class="navbar-brand" href="#">
			<img src="//fastprint.co.id/cdn/shop/t/3/assets/logo.png?v=37021879728213879011522638925" alt="Logo" width="auto" height="24" class="d-inline-block align-text-top">
		</a>
		<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
		  <span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse" id="navbarSupportedContent">
		  <ul class="navbar-nav me-auto mb-2 mb-lg-0">
			<li class="nav-item">
			  <a id="home" class="nav-link" aria-current="page" href="<?php echo site_url()?>">Home</a>
			</li>
			<li class="nav-item">
			  <a id="pengaturan-produk" class="nav-link" aria-current="page" href="<?php echo site_url("PengaturanProduk")?>">Pengaturan Produk</a>
			</li>
			
		</div>
	  </div>
	</nav>
	
