
	<div class="container mb-4">
		<!-- Content here -->
		<div class="row g-3">
			<h3>Home</h3>
			<?php
				foreach($dataProduk as $produk){
			?>
			
			<div class="col-md-3">
				<div class="card d-flex flex-column" style="height: 100%;">
				  <img src="https://cdn05.zipify.com/dr2OH-kYYHDEpkcFsHRh67lEuc4=/fit-in/1080x0/ed0b927087584f408e79de3841f9fb0d/img_9695-copy.png" class="card-img-top" alt="...">
				  <div class="card-body" >
					<h5 class="card-title"><?= $produk['nama_produk'] ?></h5>
					<p class="card-text">Rp. <?= $produk['harga'] ?></p>
					<a href="#" class="btn btn-primary">Beli</a>
				  </div>
				</div>
			</div>
			
			<?php } ?>
		
		</div>
	</div>
	<!-- jQuery -->
	<script src="<?=site_url('assets/js/jquery-3.7.1.min.js')?>"></script>
	<!-- Bootstrap JS -->
	<script src="<?=site_url('assets/js/bootstrap.bundle.min.js')?>"></script>
	<!-- DataTables JS -->
	<script src="<?=site_url('assets/js/jquery.dataTables.min.js')?>"></script>
	<script src="<?=site_url('assets/js/dataTables.bootstrap5.min.js')?>"></script>
	<!-- SweetAlert2 -->
	<script src="<?=site_url('assets/js/sweetalert2@11.js')?>"></script>
	
    
	<script>
		$(document).ready(function() {
		  $("#home").addClass("active");
		});
	</script>
  
	
  </body>
</html>
