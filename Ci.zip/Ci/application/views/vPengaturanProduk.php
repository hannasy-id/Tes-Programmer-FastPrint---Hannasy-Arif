	
	<div class="container mb-4">
		<div class="row">
			<h3>Pengaturan Produk</h3>
			<!--button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal" data-bs-whatever="@mdo">Open modal for @mdo</button>
			<button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal" data-bs-whatever="@fat">Open modal for @fat</button>
			<button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal" data-bs-whatever="@getbootstrap">Open modal for @getbootstrap</button-->
			<div class="d-flex flex-row mb-3 g-3">
				<div class="me-3">
					<button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#exampleModal" data-bs-whatever="0">Tambah Produk</button>
				</div>
				<div class="me-3">
					<button id="btn-hapus-data-database" type="button" class="btn btn-danger btn-sm">Hapus semua data dari Database</button>
				</div>
				<div class="me-3">
					<button id="btn-ambil-data-api" type="button" class="btn btn-success btn-sm">Ambil Data dari API</button>
				</div>
			</div>
			
			<div class="table-responsive">
				<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
					<thead>
						<tr>
							<th>Id Barang</th>
							<th>Nama Barang</th>
							<th>Harga</th>
							<th>Kategori</th>
							<th>Status</th>
							<th>Aksi</th>
						</tr>
					</thead>
				</table>
			</div>
		</div>
	</div>
	
	<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
	  <div class="modal-dialog">
		<div class="modal-content">
		  <div class="modal-header">
			<h1 class="modal-title fs-5" id="exampleModalLabel">New message</h1>
			<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
		  </div>
		  <div class="modal-body">
			<form>
			<div class="mb-3">
				<label for="recipient-name" class="col-form-label">Id Produk:</label>
				<input type="text" class="form-control" id="id-produk">
				<span id="err-id-produk" class="validasi-error"></span>
			  </div>
			  <div class="mb-3">
				<label for="recipient-name" class="col-form-label">Nama Produk:</label>
				<input type="text" class="form-control" id="nama-produk">
				<span id="err-nama-produk" class="validasi-error"></span>
			  </div>
			  <div class="mb-3">
				<label for="recipient-name" class="col-form-label">Harga:</label>
				<input type="text" class="form-control" id="harga">
				<span id="err-harga" class="validasi-error"></span>
			  </div>
			  <div class="mb-3">
				<label for="message-text" class="col-form-label">Kategori:</label>
				<select class="form-select" aria-label="Default select example" id="select-kategori">
					<option value="">-- Pilih Kategori --</option>
					<?php
						foreach($kategori as $selectKategori){
					?>
					  <option value="<?=$selectKategori["id_kategori"]?>"><?=$selectKategori["nama_kategori"]?></option>
					<?php } ?>
				</select>
				<span id="err-select-kategori" class="validasi-error"></span>
			  </div>
			  <div class="mb-3">
				<label for="message-text" class="col-form-label">Status:</label>
				<select class="form-select" aria-label="Default select example" id="select-status">
					<option value="">-- Pilih Status --</option>
					<?php
						foreach($status as $selectStatus){
					?>
					  <option value="<?=$selectStatus["id_status"]?>"><?=$selectStatus["nama_status"]?></option>
					<?php } ?>
				</select>
				<span id="err-select-status" class="validasi-error"></span>
			  </div>
			</form>
		  </div>
		  <div class="modal-footer">
			<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
			<button id="btn-insert-produk" type="button" class="btn btn-primary">Save</button>
			<button id="btn-update-produk" type="button" class="btn btn-primary">Update</button>
		  </div>
		</div>
	  </div>
	</div>

    <!-- jQuery -->
	<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
	<!-- Bootstrap JS -->
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
	<!-- DataTables JS -->
	<script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
	<script src="https://cdn.datatables.net/1.13.7/js/dataTables.bootstrap5.min.js"></script>
	<!-- SweetAlert2 -->
	<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
	
	<script>
		$(document).ready(function() {
			let recipient=0;
		  // Menambahkan kelas 'active' ke elemen dengan kelas 'container'
		  $("#pengaturan-produk").addClass("active");
		  
		  $('#harga').on('input', function() {
			// Menggunakan regex untuk membatasi hanya angka
			var inputVal = $(this).val();
			var numericVal = inputVal.replace(/[^0-9]/g, ''); // Hanya angka yang diperbolehkan
			$(this).val(numericVal); // Mengubah nilai input menjadi angka saja
		  });
		  
		  $('#id-produk').on('input', function() {
			// Menggunakan regex untuk membatasi hanya angka
			var inputVal = $(this).val();
			var numericVal = inputVal.replace(/[^0-9]/g, ''); // Hanya angka yang diperbolehkan
			$(this).val(numericVal); // Mengubah nilai input menjadi angka saja
		  });
		  
		  $('#exampleModal').on('show.bs.modal', function (event) {
			  
				
			  // Button yang memicu modal
			  const button = $(event.relatedTarget);
			  $(".validasi-error").text("");
			  $("#btn-insert-produk").hide();
				$("#btn-update-produk").hide();
				$('#id-produk').val('');
				$('#nama-produk').val('');
				$('#harga').val('');
				$('#select-kategori').val('');
				$('#select-status').val('');
			  // Ambil informasi dari atribut data-bs-*
			  recipient = button.data('bs-whatever');
			  //console.log(recipient);
			  if(recipient!=0){
				  $("#btn-insert-produk").hide();
					$("#btn-update-produk").show();
				  $(this).find('.modal-title').text(`Edit Produk Dengan id: ${recipient}`);
				  $.ajax({
						url: '<?= site_url("PengaturanProduk/getDataProduk")?>', // URL sesuai dengan route
						type: 'POST',
						data: {
							id_produk: recipient
						},
						dataType: 'json',
						success: function (response) {
							//$('#responseMessage').html('<p style="color: green;">' + response.message + '</p>');
							console.log(response);
							$('#id-produk').val(recipient);
							$('#nama-produk').val(response.nama_produk);
							$('#harga').val(response.harga);
							$('#select-kategori').val(response.id_kategori);
							$('#select-status').val(response.id_status);
						},
						error: function (xhr) {
							const error = xhr.responseJSON;
							
						}
					});
			  }else{
				  $("#btn-insert-produk").show();
				$("#btn-update-produk").hide();
				  $(this).find('.modal-title').text(`Tambah Produk`);
			  }
			  
			  // Update konten modal
			  //$(this).find('.modal-title').text(`New message to ${recipient}`);
			  //$(this).find('.modal-body input').val(recipient);

			});
			
			let table = $('#dataTable').DataTable({
				processing: true,
				serverSide: true,
				ajax: {
					url: "<?= site_url('PengaturanProduk/fetchData')?>",
					type: "POST",
					dataSrc: function (json) {
						console.log(json); // Debug response dari server
						return json.data; // Pastikan ini sesuai dengan key data dalam respons
					}
				},
				columns: [
					{ data: "id_produk" },
					{ data: "nama_produk" },
					{ data: "harga" },
					{ data: "nama_kategori" },
					{ data: "status" },
					{ 
						data: null,
						render: function (data, type, row) {
							let button;
							
							button = `
								<div class="d-flex flex-row mb-3 g-3">
									<div class="me-3">
										<button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#exampleModal" data-bs-whatever="`+row.id_produk+`">Edit</button>
									</div>
									<div class="me-3">
										<button type="button" class="btn btn-primary btn-sm btn-delete-produk" value="`+row.id_produk+`">hapus</button>
									</div>
								</div>	
							`;
									
							
							return button;
							 
						}
					}
					
				]
			});
			
			$("#btn-insert-produk").on("click", function(){
				var isValid = validasi();
				//console.log(isValid);
				if(isValid!=false){		
					//console.log(isValid);
					$.ajax({
						url: '<?= site_url("PengaturanProduk/insertProduk")?>', // URL sesuai dengan route
						type: 'POST',
						data: {
							idProduk: $('#id-produk').val(),
							namaProduk: $('#nama-produk').val(),
							harga: $('#harga').val(),
							kategori: $('#select-kategori').val(),
							status: $('#select-status').val()
						},
						dataType: 'json',
						success: function (response) {
							//$('#responseMessage').html('<p style="color: green;">' + response.message + '</p>');
							//console.log(response);
							
							

						},
						error: function (xhr) {
							const error = xhr.responseJSON;
							
						}
					});
					$("#exampleModal").modal('hide');
					timeout = setTimeout(() => {
						table.ajax.reload(null, false); 
					}, 500);
				}
			});
			
			$("#btn-update-produk").on("click", function(){
				var isValid = validasi();
				//console.log(isValid);
				if(isValid!=false){		
					//console.log(isValid);
					$.ajax({
						url: '<?= site_url("PengaturanProduk/updateProduk")?>', // URL sesuai dengan route
						type: 'POST',
						data: {
							idProduk: $('#id-produk').val(),
							namaProduk: $('#nama-produk').val(),
							harga: $('#harga').val(),
							kategori: $('#select-kategori').val(),
							status: $('#select-status').val()
						},
						dataType: 'json',
						success: function (response) {
							//$('#responseMessage').html('<p style="color: green;">' + response.message + '</p>');
							//console.log(response);
							
							

						},
						error: function (xhr) {
							const error = xhr.responseJSON;
							
						}
					});
					$("#exampleModal").modal('hide');
					timeout = setTimeout(() => {
						table.ajax.reload(null, false); 
					}, 500); 
				}
			});
			
			$("#btn-hapus-data-database").on("click", function(){
				console.log("tes");
				Swal.fire({
					title: 'Apakah Anda yakin ingin menghapus?',
					text: 'Semua data dari tabel produk, kategori, dan status akan dihapus',
					icon: "warning",
					showCancelButton: true,
					confirmButtonText: "OK",
					cancelButtonText: "Batal"
				}).then((result) => {
					if (result.isConfirmed) {
						$.ajax({
							url: '<?= site_url("PengaturanProduk/deleteAllTable")?>', // URL sesuai dengan route
							type: 'POST',							
							dataType: 'json',
							success: function (response) {
								//$('#responseMessage').html('<p style="color: green;">' + response.message + '</p>');
								//console.log(response);
							},
							error: function (xhr) {
								const error = xhr.responseJSON;
								
							}
						});
						timeout = setTimeout(() => {
							table.ajax.reload(null, false); 
						}, 500); 
					} else {
						// Jika tombol "Cancel" ditekan, hilangkan SweetAlert2
						console.log("Dibatalkan!");
					}
				});
			});
			
			$("#btn-ambil-data-api").on("click", function(){
				$.ajax({
					url: '<?= site_url("TesApi/getDataProduk")?>', // URL sesuai dengan route
					type: 'POST',							
					dataType: 'json',
					success: function (response) {
						//$('#responseMessage').html('<p style="color: green;">' + response.message + '</p>');
						//console.log(response);
						
					},
					error: function (xhr) {
						const error = xhr.responseJSON;
						
					}
				});
				
				timeout = setTimeout(() => {
					table.ajax.reload(null, false); 
				}, 500);
				
			});
			
			function inputValidasiKosong(idInput, idNotif, notif){
                let nilai = $(idInput).val().trim();
                if(nilai === "" || nilai === null){
                    $(idNotif).text(notif);
					return false;
                }
			}
			
			function validasi(){
				// Reset error messages
				var valid=true;
				
				$(".validasi-error").css("color", "red");
                $(".validasi-error").text("");
				
				if(inputValidasiKosong("#id-produk", "#err-id-produk", "Input tidak boleh diisi spasi atau kosong.")===false){
					valid = false;
				}
				
				if(inputValidasiKosong("#nama-produk", "#err-nama-produk", "Input tidak boleh diisi spasi atau kosong.")===false){
					valid = false;
				}
				
				if(inputValidasiKosong("#harga", "#err-harga", "Input tidak boleh diisi spasi atau kosong.")===false){
					valid = false;
				}
				
				if(inputValidasiKosong("#select-kategori", "#err-select-kategori", "Input tidak boleh diisi spasi atau kosong.")===false){
					valid = false;
				}
				
				if(inputValidasiKosong("#select-status", "#err-select-status", "Input tidak boleh diisi spasi atau kosong.")===false){
					valid = false;
				}
				
				return valid;
				
			}
			
			$(document).on("click", ".btn-delete-produk", function(){
				console.log("Button Clicked! Value:", $(this).val());
				Swal.fire({
					title: 'Apakah Anda yakin ingin menghapus?',
					icon: "warning",
					showCancelButton: true,
					confirmButtonText: "OK",
					cancelButtonText: "Batal"
				}).then((result) => {
					if (result.isConfirmed) {
						$.ajax({
							url: '<?= site_url("PengaturanProduk/deleteProduk")?>', // URL sesuai dengan route
							type: 'POST',
							data: {
								idProduk: $(this).val()
							},							
							dataType: 'json',
							success: function (response) {
								//$('#responseMessage').html('<p style="color: green;">' + response.message + '</p>');
								console.log("ok");
							},
							error: function (xhr) {
								const error = xhr.responseJSON;
								
							}
						});
						timeout = setTimeout(() => {
							table.ajax.reload(null, false); 
						}, 500); 
					} else {
						// Jika tombol "Cancel" ditekan, hilangkan SweetAlert2
						console.log("Dibatalkan!");
					}
				});
			});
			
			
			
		});
	</script>
  
	