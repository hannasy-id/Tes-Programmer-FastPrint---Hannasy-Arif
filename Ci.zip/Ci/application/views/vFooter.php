	<footer class="container-fluid bg-secondary" style="height: 100px">
		<div class="row">
		  <p class="text-center text-white mt-3 ">Author: Hannasy Arif</p>
		  <p class="text-center text-white"><a href="mailto:arifhannasy9@gmail.com">arifhannasy9@gmail.com</a></p>
		</div>
	</footer> 
	
  </body>
</html>
