<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class PengaturanProduk extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/userguide3/general/urls.html
	 */
	 
	public function __construct() {
        parent::__construct();
        $this->load->model('MPengaturanProduk'); // Memuat model Product_model
    }
	public function index()
	{
		$dataSelect=[];
		
		$dataKategori = $this->MPengaturanProduk->getAllKategori();
		
		$dataStatus = $this->MPengaturanProduk->getAllStatus();
		
		$dataSelect=["kategori"=>$dataKategori, "status"=>$dataStatus];
		
		$this->load->view('vHeader');
		$this->load->view('vPengaturanProduk', $dataSelect);
		$this->load->view('vFooter');
	}
	
	public function fetchData()
    {
		
        $draw = $this->input->post('draw');
        $start = $this->input->post('start');
        $length = $this->input->post('length');
        $searchValue = $this->input->post('search')['value'];
        $orderColumnIndex = $this->input->post('order')[0]['column'];
        $orderDirection = $this->input->post('order')[0]['dir'];
        $orderColumn = $this->input->post('columns')[$orderColumnIndex]['data'];

        // Base query
        $baseQuery = "SELECT 
						produk.id_produk AS id_produk,
						produk.nama_produk AS nama_produk,
						produk.harga AS harga,
						kategori.nama_kategori AS nama_kategori,
						status.nama_status AS status
						FROM produk
						INNER JOIN kategori ON produk.kategori_id=kategori.id_kategori
						INNER JOIN status ON produk.status_id=status.id_status

					";
		$baseTotal = $baseQuery;

        // Search filter
        if (!empty($searchValue)) {
            $baseQuery .= " WHERE produk.id_produk LIKE '%$searchValue%' OR produk.nama_produk LIKE '%$searchValue%' OR kategori.nama_kategori LIKE '%$searchValue%' OR status.nama_status LIKE '%$searchValue%'";
        }

        // Ordering
        $baseQuery .= " ORDER BY $orderColumn $orderDirection";

        // Paginate
        $paginatedQuery = $baseQuery . " LIMIT $start, $length";

        // Execute paginated query
        $query = $this->db->query($paginatedQuery);
        $data = $query->result_array();

        // Get total record counts
        $recordsTotal = $this->db->query($baseTotal)->num_rows();
        $recordsFiltered = !empty($searchValue)
            ? $this->db->query("SELECT * FROM ($baseQuery) AS subquery")->num_rows()
            : $recordsTotal;

        // Prepare response
        $response = [
            "draw" => intval($draw),
            "recordsTotal" => $recordsTotal,
            "recordsFiltered" => $recordsFiltered,
            "data" => $data,
        ];
		
		echo json_encode($response);
    }
	
	public function getDataProduk(){
		$id_produk = $this->input->post('id_produk');
		
		$dataProduk = $this->MPengaturanProduk->getProduk($id_produk);
		echo json_encode($dataProduk);
	}
	
	public function insertProduk(){
		
		$idProduk = $this->input->post('idProduk');
		$namaProduk = $this->input->post('namaProduk');
		$harga = $this->input->post('harga');
		$kategori = $this->input->post('kategori');
		$status = $this->input->post('status');
			
		$this->MPengaturanProduk->insertProduk($idProduk, $namaProduk, $harga, $kategori, $status);
	}
	
	public function updateProduk(){
		
		$idProduk = $this->input->post('idProduk');
		$namaProduk = $this->input->post('namaProduk');
		$harga = $this->input->post('harga');
		$kategori = $this->input->post('kategori');
		$status = $this->input->post('status');
					
		$this->MPengaturanProduk->updateProduk($idProduk, $namaProduk, $harga, $kategori, $status);
	}
	
	public function deleteAllTable(){
		
		$this->MPengaturanProduk->deleteAllTable();
	}
	
	public function deleteProduk(){
		$idProduk = $this->input->post("idProduk");
		
		//$query = "DELETE FROM produk WHERE id_produk = $idProduk";
		//$this->db->query($query);
		$this->MPengaturanProduk->deleteProduk($idProduk);
		
	}
}
