<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class TesApi extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/userguide3/general/urls.html
	 */
	 
	public function __construct() {
        parent::__construct();
        $this->load->model('MTesApi'); 
    }
	
	public function index()
	{
		//$this->load->view('welcome_message');
	}
	
	public function getDataProduk() {
		
		$dataArray = $this->MTesApi->getDataProduk();//json_decode($response, true)['data'];
		/*
		echo "<pre>";
		print_r($dataArray);
		echo "<pre>";
		*/
		$dataKategori=[];
		$dataStatus=[];
		foreach($dataArray as $dataKtgr){
			if(count($dataKategori)==0){$dataKategori[] = ['id_kategori'=>1, 'nama_kategori'=>$dataKtgr['kategori']];}
			for($i = 0; $i<count($dataKategori); $i++){
				if($dataKtgr['kategori']!=$dataKategori[$i]['nama_kategori'] && $i==(count($dataKategori)-1)){
					$dataKategori[] = ['id_kategori'=>$i+2, 'nama_kategori'=>$dataKtgr['kategori']];
				}else if($dataKtgr['kategori']==$dataKategori[$i]['nama_kategori']){
					break;
				}
			}
			
			if(count($dataStatus)==0){
				$dataStatus[] = ['id_status'=>1, 'nama_status'=>$dataKtgr['status']];
			}
			for($j = 0; $j<count($dataStatus); $j++){
				//echo $dataKtgr['status'];
				if($dataKtgr['status']!=$dataStatus[$j]['nama_status'] && $j==(count($dataStatus)-1)){
					$dataStatus[] = ['id_status'=>$j+2, 'nama_status'=>$dataKtgr['status']];
				}else if($dataKtgr['status']==$dataStatus[$j]['nama_status']){
					break;
				}
			}
			
		}
	/*
		echo "<pre>";
		print_r($dataKategori);
		echo "<pre>";
		
		echo "<pre>";
		print_r($dataStatus);
		echo "<pre>";
		*/
		
		$this->db->insert_batch('kategori', $dataKategori); // Masukkan semua data sekaligus
		
		
		$this->db->insert_batch('status', $dataStatus); // Masukkan semua data sekaligus
		
		$dataProduk=[];
		$dataPrdKategori=0;
		$dataPrdStatus=0;
		foreach($dataArray as $dataPrd){
			for($i = 0; $i<count($dataKategori); $i++){
				if($dataPrd['kategori']==$dataKategori[$i]['nama_kategori']){
					$dataPrdKategori=$dataKategori[$i]['id_kategori'];
					break;
				}
			}
			
			for($j = 0; $j<count($dataStatus); $j++){
				if($dataPrd['status']==$dataStatus[$j]['nama_status']){
					$dataPrdStatus=$dataStatus[$j]['id_status'];
					break;
				}
			}
			
			$dataProduk[]=[
				'id_produk'=>$dataPrd['id_produk'],
				'nama_produk'=>$dataPrd['nama_produk'],
				'harga'=>$dataPrd['harga'],
				'kategori_id'=>$dataPrdKategori,
				'status_id'=>$dataPrdStatus,
			];
		}
		
		/*echo "<pre>";
		print_r($dataProduk);
		echo "<pre>";*/
		
		
		$this->db->insert_batch('produk', $dataProduk); // Masukkan semua data sekaligus
		
	}

}
